
const taskArray = (arr) => {
    // задача: сформировать новый массив из элементов соответсвующих условию n > 0, исходный массив: [-1, -2, -4, -5, 5, 5, 0] 
    return arr.filter((el) => el < 0)
}

module.exports = taskArray;